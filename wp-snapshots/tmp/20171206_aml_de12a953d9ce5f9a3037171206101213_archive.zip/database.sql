-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: aml
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aml_clinicaltrials`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_clinicaltrials` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text,
  `sites` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_clinicaltrials`
--

LOCK TABLES `aml_clinicaltrials` WRITE;
/*!40000 ALTER TABLE `aml_clinicaltrials` DISABLE KEYS */;
INSERT INTO `aml_clinicaltrials` VALUES (1,'CT65','מחקר 65\r\n','a:2:{i:0;s:1:\"1\";i:1;s:1:\"5\";}'),(2,'CT43','מחקר חשוב 43','a:3:{i:0;s:1:\"1\";i:1;s:1:\"3\";i:2;s:1:\"4\";}'),(6,'CT77','this is a new ct desc','a:2:{i:0;s:1:\"4\";i:1;s:1:\"5\";}'),(7,'123','123','a:2:{i:0;s:1:\"1\";i:1;s:1:\"3\";}');
/*!40000 ALTER TABLE `aml_clinicaltrials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_couriers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_couriers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `dry_ice` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_couriers`
--

LOCK TABLES `aml_couriers` WRITE;
/*!40000 ALTER TABLE `aml_couriers` DISABLE KEYS */;
INSERT INTO `aml_couriers` VALUES (6,'במהירות הכל','email1@email1.com',1),(7,'גולן','golan@gmail.com',0);
/*!40000 ALTER TABLE `aml_couriers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_couriers_zones`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_couriers_zones` (
  `courier_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_couriers_zones`
--

LOCK TABLES `aml_couriers_zones` WRITE;
/*!40000 ALTER TABLE `aml_couriers_zones` DISABLE KEYS */;
INSERT INTO `aml_couriers_zones` VALUES (7,3),(7,4),(6,1),(6,2),(9,1),(9,2);
/*!40000 ALTER TABLE `aml_couriers_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_pickup_types`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_pickup_types` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `taxi` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_pickup_types`
--

LOCK TABLES `aml_pickup_types` WRITE;
/*!40000 ALTER TABLE `aml_pickup_types` DISABLE KEYS */;
INSERT INTO `aml_pickup_types` VALUES (6,'רגיל','טקסט טקסט תיאור 1',0),(7,'קרח יבש','טקסט תיאור 2',0),(8,'קרח יבש ומונית ','טקסט תיאור 3',1),(9,'מונית','טקסט תיאור 4\r\n',1),(10,'קטנוע','טקסט תיאור 5',0);
/*!40000 ALTER TABLE `aml_pickup_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_sites`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_sites` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `department` text NOT NULL,
  `address` text NOT NULL,
  `zone` int(11) NOT NULL,
  `time_limit` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_sites`
--

LOCK TABLES `aml_sites` WRITE;
/*!40000 ALTER TABLE `aml_sites` DISABLE KEYS */;
INSERT INTO `aml_sites` VALUES (1,'תל השומר','עיניים','כתובת 1',2,'17:00'),(3,'תל השומר','ילדים','כתובת 1',2,'17:00'),(4,'זיו','אורתופדיה','כתובת 2',1,'15:00'),(5,'סורוקה','עיניים','כתובת 4',3,'15:00');
/*!40000 ALTER TABLE `aml_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_targets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_targets` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `address` text,
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_targets`
--

LOCK TABLES `aml_targets` WRITE;
/*!40000 ALTER TABLE `aml_targets` DISABLE KEYS */;
INSERT INTO `aml_targets` VALUES (1,'אמל בית נוי','טקסט 2'),(2,'סורוקה מעבדה 5','1 address street'),(3,'אמל רמת אביב','טקסט 3'),(4,'שיבא מעבדה 8','כתובת 8');
/*!40000 ALTER TABLE `aml_targets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_visits`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_visits` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `clinical_trial` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_visits`
--

LOCK TABLES `aml_visits` WRITE;
/*!40000 ALTER TABLE `aml_visits` DISABLE KEYS */;
INSERT INTO `aml_visits` VALUES (1,'Visit 1 – CT65',1),(2,'Visit 2 – CT65',1),(5,'Visit 3 – CT65',1),(6,'Visit 1 – CT43',2),(7,'Visit 2 – CT43',2),(9,'Visit 3 – CT43',2),(10,'Visit 1 – CT77',1),(11,'Visit 1 – 123',1);
/*!40000 ALTER TABLE `aml_visits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aml_zones`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aml_zones` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aml_zones`
--

LOCK TABLES `aml_zones` WRITE;
/*!40000 ALTER TABLE `aml_zones` DISABLE KEYS */;
INSERT INTO `aml_zones` VALUES (1,'צפון'),(2,'דרום'),(3,'מרכז'),(4,'ירושלים');
/*!40000 ALTER TABLE `aml_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_commentmeta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES (1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2017-11-18 18:50:15','2017-11-18 18:50:15','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.',0,'post-trashed','','',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_duplicator_packages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_duplicator_packages`
--

LOCK TABLES `wp_duplicator_packages` WRITE;
/*!40000 ALTER TABLE `wp_duplicator_packages` DISABLE KEYS */;
INSERT INTO `wp_duplicator_packages` VALUES (1,'20171206_aml','de12a953d9ce5f9a3037171206101213',20,'2017-12-06 10:15:00','OshikErnst',0x4F3A31313A224455505F5061636B616765223A32333A7B733A373A2243726561746564223B733A31393A22323031372D31322D30362031303A31323A3133223B733A373A2256657273696F6E223B733A363A22312E322E3330223B733A393A2256657273696F6E5750223B733A353A22342E392E31223B733A393A2256657273696F6E4442223B733A373A2231302E312E3236223B733A31303A2256657273696F6E504850223B733A353A22372E312E38223B733A393A2256657273696F6E4F53223B733A353A2257494E4E54223B733A323A224944223B693A313B733A343A224E616D65223B733A31323A2232303137313230365F616D6C223B733A343A2248617368223B733A33323A226465313261393533643963653566396133303337313731323036313031323133223B733A383A224E616D6548617368223B733A34353A2232303137313230365F616D6C5F6465313261393533643963653566396133303337313731323036313031323133223B733A343A2254797065223B693A303B733A353A224E6F746573223B733A303A22223B733A393A2253746F726550617468223B733A33363A22433A2F78616D70702F6874646F63732F616D6C2F77702D736E617073686F74732F746D70223B733A383A2253746F726555524C223B733A33343A22687474703A2F2F6C6F63616C686F73742F616D6C2F77702D736E617073686F74732F223B733A383A225363616E46696C65223B733A35353A2232303137313230365F616D6C5F64653132613935336439636535663961333033373137313230363130313231335F7363616E2E6A736F6E223B733A373A2252756E74696D65223B4E3B733A373A2245786553697A65223B4E3B733A373A225A697053697A65223B4E3B733A363A22537461747573223B4E3B733A363A22575055736572223B733A31303A224F7368696B45726E7374223B733A373A2241726368697665223B4F3A31313A224455505F41726368697665223A31383A7B733A31303A2246696C74657244697273223B733A303A22223B733A31313A2246696C74657246696C6573223B733A303A22223B733A31303A2246696C74657245787473223B733A303A22223B733A31333A2246696C74657244697273416C6C223B613A303A7B7D733A31343A2246696C74657246696C6573416C6C223B613A303A7B7D733A31333A2246696C74657245787473416C6C223B613A303A7B7D733A383A2246696C7465724F6E223B693A303B733A31323A224578706F72744F6E6C794442223B693A303B733A343A2246696C65223B733A35373A2232303137313230365F616D6C5F64653132613935336439636535663961333033373137313230363130313231335F617263686976652E7A6970223B733A363A22466F726D6174223B733A333A225A4950223B733A373A225061636B446972223B733A31393A22433A2F78616D70702F6874646F63732F616D6C223B733A343A2253697A65223B693A303B733A343A2244697273223B613A303A7B7D733A353A2246696C6573223B613A303A7B7D733A31303A2246696C746572496E666F223B4F3A32333A224455505F417263686976655F46696C7465725F496E666F223A383A7B733A343A2244697273223B4F3A33343A224455505F417263686976655F46696C7465725F53636F70655F4469726563746F7279223A343A7B733A373A225761726E696E67223B613A303A7B7D733A31303A22556E7265616461626C65223B613A303A7B7D733A343A22436F7265223B613A303A7B7D733A383A22496E7374616E6365223B613A303A7B7D7D733A353A2246696C6573223B4F3A32393A224455505F417263686976655F46696C7465725F53636F70655F46696C65223A353A7B733A343A2253697A65223B613A303A7B7D733A373A225761726E696E67223B613A303A7B7D733A31303A22556E7265616461626C65223B613A303A7B7D733A343A22436F7265223B613A303A7B7D733A383A22496E7374616E6365223B613A303A7B7D7D733A343A2245787473223B4F3A32393A224455505F417263686976655F46696C7465725F53636F70655F42617365223A323A7B733A343A22436F7265223B613A303A7B7D733A383A22496E7374616E6365223B613A303A7B7D7D733A393A2255446972436F756E74223B693A303B733A31303A225546696C65436F756E74223B693A303B733A393A2255457874436F756E74223B693A303B733A383A225472656553697A65223B613A303A7B7D733A31313A22547265655761726E696E67223B613A303A7B7D7D733A31303A22002A005061636B616765223B4F3A31313A224455505F5061636B616765223A32333A7B733A373A2243726561746564223B733A31393A22323031372D31322D30362031303A31323A3133223B733A373A2256657273696F6E223B733A363A22312E322E3330223B733A393A2256657273696F6E5750223B733A353A22342E392E31223B733A393A2256657273696F6E4442223B733A373A2231302E312E3236223B733A31303A2256657273696F6E504850223B733A353A22372E312E38223B733A393A2256657273696F6E4F53223B733A353A2257494E4E54223B733A323A224944223B4E3B733A343A224E616D65223B733A31323A2232303137313230365F616D6C223B733A343A2248617368223B733A33323A226465313261393533643963653566396133303337313731323036313031323133223B733A383A224E616D6548617368223B733A34353A2232303137313230365F616D6C5F6465313261393533643963653566396133303337313731323036313031323133223B733A343A2254797065223B693A303B733A353A224E6F746573223B733A303A22223B733A393A2253746F726550617468223B733A33363A22433A2F78616D70702F6874646F63732F616D6C2F77702D736E617073686F74732F746D70223B733A383A2253746F726555524C223B733A33343A22687474703A2F2F6C6F63616C686F73742F616D6C2F77702D736E617073686F74732F223B733A383A225363616E46696C65223B4E3B733A373A2252756E74696D65223B4E3B733A373A2245786553697A65223B4E3B733A373A225A697053697A65223B4E3B733A363A22537461747573223B4E3B733A363A22575055736572223B4E3B733A373A2241726368697665223B723A32323B733A393A22496E7374616C6C6572223B4F3A31333A224455505F496E7374616C6C6572223A373A7B733A343A2246696C65223B733A35393A2232303137313230365F616D6C5F64653132613935336439636535663961333033373137313230363130313231335F696E7374616C6C65722E706870223B733A343A2253697A65223B693A303B733A31303A224F7074734442486F7374223B733A303A22223B733A31303A224F7074734442506F7274223B733A303A22223B733A31303A224F70747344424E616D65223B733A303A22223B733A31303A224F707473444255736572223B733A303A22223B733A31303A22002A005061636B616765223B723A35373B7D733A383A224461746162617365223B4F3A31323A224455505F4461746162617365223A31333A7B733A343A2254797065223B733A353A224D7953514C223B733A343A2253697A65223B4E3B733A343A2246696C65223B733A35383A2232303137313230365F616D6C5F64653132613935336439636535663961333033373137313230363130313231335F64617461626173652E73716C223B733A343A2250617468223B4E3B733A31323A2246696C7465725461626C6573223B733A303A22223B733A383A2246696C7465724F6E223B693A303B733A343A224E616D65223B4E3B733A31303A22436F6D70617469626C65223B733A303A22223B733A383A22436F6D6D656E7473223B733A33313A226D6172696164622E6F72672062696E61727920646973747269627574696F6E223B733A31303A22002A005061636B616765223B723A313B733A32353A22004455505F446174616261736500646253746F726550617468223B4E3B733A32333A22004455505F446174616261736500454F464D61726B6572223B733A303A22223B733A32363A22004455505F4461746162617365006E6574776F726B466C757368223B623A303B7D7D733A32393A22004455505F4172636869766500746D7046696C74657244697273416C6C223B613A303A7B7D733A32343A22004455505F41726368697665007770436F72655061746873223B613A363A7B693A303B733A32383A22433A2F78616D70702F6874646F63732F616D6C2F77702D61646D696E223B693A313B733A33383A22433A2F78616D70702F6874646F63732F616D6C2F77702D636F6E74656E742F75706C6F616473223B693A323B733A34303A22433A2F78616D70702F6874646F63732F616D6C2F77702D636F6E74656E742F6C616E677561676573223B693A333B733A33383A22433A2F78616D70702F6874646F63732F616D6C2F77702D636F6E74656E742F706C7567696E73223B693A343B733A33373A22433A2F78616D70702F6874646F63732F616D6C2F77702D636F6E74656E742F7468656D6573223B693A353B733A33313A22433A2F78616D70702F6874646F63732F616D6C2F77702D696E636C75646573223B7D7D733A393A22496E7374616C6C6572223B723A37393B733A383A224461746162617365223B723A38373B7D);
/*!40000 ALTER TABLE `wp_duplicator_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=412 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,'siteurl','http://localhost/aml','yes'),(2,'home','http://localhost/aml','yes'),(3,'blogname','AML','yes'),(4,'blogdescription','Just another WordPress site','yes'),(5,'users_can_register','0','yes'),(6,'admin_email','oshike@gmail.com','yes'),(7,'start_of_week','1','yes'),(8,'use_balanceTags','0','yes'),(9,'use_smilies','1','yes'),(10,'require_name_email','1','yes'),(11,'comments_notify','1','yes'),(12,'posts_per_rss','10','yes'),(13,'rss_use_excerpt','0','yes'),(14,'mailserver_url','mail.example.com','yes'),(15,'mailserver_login','login@example.com','yes'),(16,'mailserver_pass','password','yes'),(17,'mailserver_port','110','yes'),(18,'default_category','1','yes'),(19,'default_comment_status','open','yes'),(20,'default_ping_status','open','yes'),(21,'default_pingback_flag','1','yes'),(22,'posts_per_page','10','yes'),(23,'date_format','F j, Y','yes'),(24,'time_format','g:i a','yes'),(25,'links_updated_date_format','F j, Y g:i a','yes'),(26,'comment_moderation','0','yes'),(27,'moderation_notify','1','yes'),(28,'permalink_structure','/%postname%/','yes'),(29,'rewrite_rules','a:86:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','yes'),(30,'hack_file','0','yes'),(31,'blog_charset','UTF-8','yes'),(32,'moderation_keys','','no'),(33,'active_plugins','a:1:{i:0;s:25:\"duplicator/duplicator.php\";}','yes'),(34,'category_base','','yes'),(35,'ping_sites','http://rpc.pingomatic.com/','yes'),(36,'comment_max_links','2','yes'),(37,'gmt_offset','0','yes'),(38,'default_email_category','1','yes'),(39,'recently_edited','a:2:{i:0;s:51:\"C:\\xampp\\htdocs\\aml/wp-content/themes/aml/style.css\";i:2;s:0:\"\";}','no'),(40,'template','aml','yes'),(41,'stylesheet','aml','yes'),(42,'comment_whitelist','1','yes'),(43,'blacklist_keys','','no'),(44,'comment_registration','0','yes'),(45,'html_type','text/html','yes'),(46,'use_trackback','0','yes'),(47,'default_role','subscriber','yes'),(48,'db_version','38590','yes'),(49,'uploads_use_yearmonth_folders','1','yes'),(50,'upload_path','','yes'),(51,'blog_public','1','yes'),(52,'default_link_category','2','yes'),(53,'show_on_front','posts','yes'),(54,'tag_base','','yes'),(55,'show_avatars','1','yes'),(56,'avatar_rating','G','yes'),(57,'upload_url_path','','yes'),(58,'thumbnail_size_w','150','yes'),(59,'thumbnail_size_h','150','yes'),(60,'thumbnail_crop','1','yes'),(61,'medium_size_w','300','yes'),(62,'medium_size_h','300','yes'),(63,'avatar_default','mystery','yes'),(64,'large_size_w','1024','yes'),(65,'large_size_h','1024','yes'),(66,'image_default_link_type','none','yes'),(67,'image_default_size','','yes'),(68,'image_default_align','','yes'),(69,'close_comments_for_old_posts','0','yes'),(70,'close_comments_days_old','14','yes'),(71,'thread_comments','1','yes'),(72,'thread_comments_depth','5','yes'),(73,'page_comments','0','yes'),(74,'comments_per_page','50','yes'),(75,'default_comments_page','newest','yes'),(76,'comment_order','asc','yes'),(77,'sticky_posts','a:0:{}','yes'),(78,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(79,'widget_text','a:5:{i:2;a:4:{s:5:\"title\";s:7:\"Find Us\";s:4:\"text\";s:168:\"<strong>Address</strong>\n123 Main Street\nNew York, NY 10001\n\n<strong>Hours</strong>\nMonday&mdash;Friday: 9:00AM&ndash;5:00PM\nSaturday &amp; Sunday: 11:00AM&ndash;3:00PM\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:15:\"About This Site\";s:4:\"text\";s:85:\"This may be a good place to introduce yourself and your site or include some credits.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:4;a:4:{s:5:\"title\";s:7:\"Find Us\";s:4:\"text\";s:168:\"<strong>Address</strong>\n123 Main Street\nNew York, NY 10001\n\n<strong>Hours</strong>\nMonday&mdash;Friday: 9:00AM&ndash;5:00PM\nSaturday &amp; Sunday: 11:00AM&ndash;3:00PM\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:5;a:4:{s:5:\"title\";s:15:\"About This Site\";s:4:\"text\";s:85:\"This may be a good place to introduce yourself and your site or include some credits.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}','yes'),(80,'widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(81,'uninstall_plugins','a:1:{s:47:\"advanced-page-manager/advanced_page_manager.php\";a:2:{i:0;s:21:\"advanced_page_manager\";i:1;s:9:\"uninstall\";}}','no'),(82,'timezone_string','','yes'),(83,'page_for_posts','0','yes'),(84,'page_on_front','0','yes'),(85,'default_post_format','0','yes'),(86,'link_manager_enabled','0','yes'),(87,'finished_splitting_shared_terms','1','yes'),(88,'site_icon','0','yes'),(89,'medium_large_size_w','768','yes'),(90,'medium_large_size_h','0','yes'),(91,'initial_db_version','38590','yes'),(92,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:63:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"swifty_edit_locked\";b:1;s:18:\"swifty_change_lock\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),(93,'fresh_site','0','yes'),(94,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(95,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(96,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(97,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(98,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(99,'sidebars_widgets','a:2:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:6:\"text-4\";i:3;s:6:\"text-5\";i:4;s:8:\"search-2\";i:5;s:14:\"recent-posts-2\";i:6;s:17:\"recent-comments-2\";i:7;s:10:\"archives-2\";i:8;s:12:\"categories-2\";i:9;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}','yes'),(100,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(101,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(102,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(103,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(104,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(105,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(106,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(107,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(108,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(109,'cron','a:4:{i:1512586217;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1512586318;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1512587989;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','yes'),(110,'theme_mods_twentyseventeen','a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511033782;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}','yes'),(119,'_site_transient_update_themes','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1512555055;s:7:\"checked\";a:1:{s:3:\"aml\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}','no'),(123,'can_compress_scripts','1','no'),(145,'current_theme','aml','yes'),(146,'theme_mods_aml','a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511085623;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:6:\"text-4\";i:3;s:6:\"text-5\";i:4;s:8:\"search-2\";i:5;s:14:\"recent-posts-2\";i:6;s:17:\"recent-comments-2\";i:7;s:10:\"archives-2\";i:8;s:12:\"categories-2\";i:9;s:6:\"meta-2\";}}}}','yes'),(147,'theme_switched','','yes'),(153,'theme_mods_twentyfifteen','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511036960;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:6:\"text-4\";i:3;s:6:\"text-5\";i:4;s:8:\"search-2\";i:5;s:14:\"recent-posts-2\";i:6;s:17:\"recent-comments-2\";i:7;s:10:\"archives-2\";i:8;s:12:\"categories-2\";i:9;s:6:\"meta-2\";}s:9:\"sidebar-1\";a:0:{}}}}','yes'),(185,'theme_mods_twentyfourteen','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511085634;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:6:\"text-4\";i:3;s:6:\"text-5\";i:4;s:8:\"search-2\";i:5;s:14:\"recent-posts-2\";i:6;s:17:\"recent-comments-2\";i:7;s:10:\"archives-2\";i:8;s:12:\"categories-2\";i:9;s:6:\"meta-2\";}s:9:\"sidebar-1\";a:0:{}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}','yes'),(186,'widget_widget_twentyfourteen_ephemera','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(192,'WPLANG','','yes'),(193,'new_admin_email','oshike@gmail.com','yes'),(214,'recently_activated','a:0:{}','yes'),(221,'swifty_lib_version','undefined','yes'),(222,'spm_plugin_options','a:1:{s:19:\"page_tree_max_width\";i:900;}','yes'),(313,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.1\";s:7:\"version\";s:5:\"4.9.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1512555052;s:15:\"version_checked\";s:5:\"4.9.1\";s:12:\"translations\";a:0:{}}','no'),(314,'auto_core_update_notified','a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:16:\"oshike@gmail.com\";s:7:\"version\";s:5:\"4.9.1\";s:9:\"timestamp\";i:1512035070;}','no'),(375,'category_children','a:0:{}','yes'),(401,'_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a','1512565826','no'),(402,'_site_transient_poptags_40cd750bba9870f18aada2478b24840a','O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4406;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2518;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:2455;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2380;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1846;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1616;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1609;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1439;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1367;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1366;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1351;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1281;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1278;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1161;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1071;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1055;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1004;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:967;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:841;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:837;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:817;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:783;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:775;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:681;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:675;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:670;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:670;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:662;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:650;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:641;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:638;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:618;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:615;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:600;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:592;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:590;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:588;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:583;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:572;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:570;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:550;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:541;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:529;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:526;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:513;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:504;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:504;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:495;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:485;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:481;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:480;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:475;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:459;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:456;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:456;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:452;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:449;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:446;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:429;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:416;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:416;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:416;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:410;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:410;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:407;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:401;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:397;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:389;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:385;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:378;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:358;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:350;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:350;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:345;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:337;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:337;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:336;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:332;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:331;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:330;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:327;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:325;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:324;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:321;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:315;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:306;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:303;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:300;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:299;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:298;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:297;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:290;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:288;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:287;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:286;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:281;}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";i:281;}s:7:\"tinymce\";a:3:{s:4:\"name\";s:7:\"tinyMCE\";s:4:\"slug\";s:7:\"tinymce\";s:5:\"count\";i:278;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:277;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:277;}}','no'),(404,'_site_transient_timeout_theme_roots','1512556854','no'),(405,'_site_transient_theme_roots','a:1:{s:3:\"aml\";s:7:\"/themes\";}','no'),(406,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1512555120;s:7:\"checked\";a:2:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.5.12\";s:25:\"duplicator/duplicator.php\";s:6:\"1.2.30\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:1:{s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.30\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.30.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:7:\"default\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";s:7:\"default\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}}}}','no'),(407,'duplicator_settings','a:10:{s:7:\"version\";s:6:\"1.2.30\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}','yes'),(408,'duplicator_version_plugin','1.2.30','yes'),(409,'_transient_timeout_plugin_slugs','1512641523','no'),(410,'_transient_plugin_slugs','a:2:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:25:\"duplicator/duplicator.php\";}','no'),(411,'duplicator_package_active','O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-12-06 10:12:13\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:5:\"4.9.1\";s:9:\"VersionDB\";s:7:\"10.1.26\";s:10:\"VersionPHP\";s:5:\"7.1.8\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:12:\"20171206_aml\";s:4:\"Hash\";s:32:\"de12a953d9ce5f9a3037171206101213\";s:8:\"NameHash\";s:45:\"20171206_aml_de12a953d9ce5f9a3037171206101213\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:36:\"C:/xampp/htdocs/aml/wp-snapshots/tmp\";s:8:\"StoreURL\";s:34:\"http://localhost/aml/wp-snapshots/\";s:8:\"ScanFile\";s:55:\"20171206_aml_de12a953d9ce5f9a3037171206101213_scan.json\";s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";O:11:\"DUP_Archive\":18:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";N;s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:19:\"C:/xampp/htdocs/aml\";s:4:\"Size\";i:0;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:10:\"\0*\0Package\";O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-12-06 10:12:13\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:5:\"4.9.1\";s:9:\"VersionDB\";s:7:\"10.1.26\";s:10:\"VersionPHP\";s:5:\"7.1.8\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:12:\"20171206_aml\";s:4:\"Hash\";s:32:\"de12a953d9ce5f9a3037171206101213\";s:8:\"NameHash\";s:45:\"20171206_aml_de12a953d9ce5f9a3037171206101213\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:36:\"C:/xampp/htdocs/aml/wp-snapshots/tmp\";s:8:\"StoreURL\";s:34:\"http://localhost/aml/wp-snapshots/\";s:8:\"ScanFile\";N;s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";r:22;s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";N;s:4:\"Size\";i:0;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:57;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";N;s:4:\"File\";N;s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:31:\"mariadb.org binary distribution\";s:10:\"\0*\0Package\";r:57;s:25:\"\0DUP_Database\0dbStorePath\";N;s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:28:\"C:/xampp/htdocs/aml/wp-admin\";i:1;s:38:\"C:/xampp/htdocs/aml/wp-content/uploads\";i:2;s:40:\"C:/xampp/htdocs/aml/wp-content/languages\";i:3;s:38:\"C:/xampp/htdocs/aml/wp-content/plugins\";i:4;s:37:\"C:/xampp/htdocs/aml/wp-content/themes\";i:5;s:31:\"C:/xampp/htdocs/aml/wp-includes\";}}s:9:\"Installer\";r:79;s:8:\"Database\";r:87;}','yes');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=367 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (34,22,'_edit_last','1'),(35,22,'_edit_lock','1511036630:1'),(36,22,'_wp_page_template','aml_user.php'),(46,29,'_edit_lock','1511086032:1'),(47,29,'_edit_last','1'),(48,29,'_wp_page_template','aml_login.php'),(49,32,'_edit_lock','1511078822:1'),(50,32,'_edit_last','1'),(51,32,'_wp_page_template','aml_users.php'),(52,35,'_edit_lock','1511085860:1'),(53,35,'_edit_last','1'),(54,35,'_wp_page_template','aml_new_user.php'),(55,37,'_edit_lock','1511086716:1'),(56,37,'_edit_last','1'),(57,37,'_wp_page_template','aml_clinicaltrials.php'),(74,59,'_edit_lock','1511087250:1'),(75,59,'_edit_last','1'),(76,59,'_wp_page_template','aml_clinicaltrial.php'),(77,61,'_edit_lock','1511100585:1'),(78,61,'_edit_last','1'),(79,61,'_wp_page_template','aml_new_clinicaltrial.php'),(80,63,'_edit_lock','1511168506:1'),(81,63,'_edit_last','1'),(82,63,'_wp_page_template','aml_sites.php'),(99,77,'_edit_last','1'),(100,77,'_wp_page_template','aml_site.php'),(101,77,'_edit_lock','1511169178:1'),(105,79,'_edit_lock','1511171599:1'),(106,79,'_edit_last','1'),(107,79,'_wp_page_template','aml_new_site.php'),(108,81,'_edit_lock','1511174552:1'),(109,81,'_edit_last','1'),(112,81,'_wp_page_template','aml_visits.php'),(113,85,'_edit_lock','1511174587:1'),(114,85,'_edit_last','1'),(115,85,'_wp_page_template','aml_visit.php'),(116,87,'_edit_lock','1511174598:1'),(117,87,'_edit_last','1'),(118,87,'_wp_page_template','aml_new_visit.php'),(119,89,'_edit_lock','1511174637:1'),(120,89,'_edit_last','1'),(121,89,'_wp_page_template','aml_pickup_types.php'),(122,93,'_edit_lock','1511174645:1'),(123,93,'_edit_last','1'),(124,93,'_wp_page_template','aml_pickup_type.php'),(125,95,'_edit_lock','1511174653:1'),(126,95,'_edit_last','1'),(127,95,'_wp_page_template','aml_new_pickup_type.php'),(128,97,'_edit_lock','1511174667:1'),(129,97,'_edit_last','1'),(130,97,'_wp_page_template','aml_couriers.php'),(131,99,'_edit_lock','1511174677:1'),(132,99,'_edit_last','1'),(133,99,'_wp_page_template','aml_courier.php'),(134,101,'_edit_lock','1511175078:1'),(135,101,'_edit_last','1'),(136,101,'_wp_page_template','aml_new_courier.php'),(137,103,'_edit_lock','1512078775:1'),(138,103,'_edit_last','1'),(139,103,'_wp_page_template','aml_new_form.php'),(140,107,'_edit_lock','1511682965:1'),(141,107,'_edit_last','1'),(142,107,'_wp_page_template','aml_zones.php'),(143,109,'_edit_lock','1511682976:1'),(144,109,'_edit_last','1'),(145,109,'_wp_page_template','aml_new_zone.php'),(146,111,'_edit_lock','1511683370:1'),(147,111,'_edit_last','1'),(148,111,'_wp_page_template','aml_zone.php'),(158,125,'_edit_last','1'),(159,125,'_wp_page_template','aml_targets.php'),(160,125,'_edit_lock','1511684607:1'),(161,127,'_edit_lock','1511684621:1'),(162,127,'_edit_last','1'),(163,127,'_wp_page_template','aml_target.php'),(164,129,'_edit_lock','1511684872:1'),(165,129,'_edit_last','1'),(166,129,'_wp_page_template','aml_new_target.php'),(169,131,'_edit_lock','1512078921:1'),(172,132,'_edit_lock','1512243382:1'),(175,133,'_edit_lock','1512079146:1'),(178,134,'ctcodes','1'),(179,134,'visits','s:30:\"a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}\";'),(180,134,'sites','5'),(181,134,'address','כתובת 4'),(182,134,'department','עיניים'),(183,134,'targets','1'),(184,134,'contact','Oshik'),(185,134,'phone','502066635'),(186,134,'pickup','6'),(187,134,'zone','1'),(188,134,'courier','6'),(189,134,'courier_email','email1@email1.com'),(190,134,'taxi_hour','10'),(191,134,'taxi_mins','30'),(192,134,'hour_from','8'),(193,134,'hour_to','10'),(194,134,'date','2017-12-26'),(195,134,'notes','notes notes notesss'),(196,134,'_edit_lock','1512309884:1'),(197,135,'_edit_last','1'),(198,135,'_wp_page_template','aml_forms.php'),(199,135,'_edit_lock','1512163311:1'),(200,1,'_wp_trash_meta_status','publish'),(201,1,'_wp_trash_meta_time','1512163458'),(202,1,'_wp_desired_post_slug','hello-world'),(203,1,'_wp_trash_meta_comments_status','a:1:{i:1;s:1:\"1\";}'),(204,131,'_wp_trash_meta_status','publish'),(205,131,'_wp_trash_meta_time','1512164069'),(206,131,'_wp_desired_post_slug','form-sent-by-oshik-ernst-on-215726-957-pm'),(207,139,'_edit_lock','1512243151:1'),(208,139,'_edit_last','1'),(209,139,'_wp_page_template','aml_form.php'),(210,134,'_edit_last','1'),(215,142,'ctcodes','-1'),(216,142,'visits','s:19:\"a:1:{i:0;s:2:\"-1\";}\";'),(217,142,'sites','4'),(218,142,'address','כתובת 2'),(219,142,'department','אורתופדיה'),(220,142,'targets','-1'),(221,142,'contact',''),(222,142,'phone',''),(223,142,'pickup','-1'),(224,142,'zone','1'),(225,142,'courier','6'),(226,142,'courier_email','email1@email1.com'),(227,142,'taxi_hour','10'),(228,142,'taxi_mins','30'),(229,142,'hour_from','8'),(230,142,'hour_to','10'),(231,142,'date','2017-12-27'),(232,142,'notes',''),(233,142,'_edit_lock','1512306215:1'),(234,142,'_wp_trash_meta_status','publish'),(235,142,'_wp_trash_meta_time','1512306359'),(236,142,'_wp_desired_post_slug','form-sent-by-oshikernst'),(241,144,'ctcodes','-1'),(242,144,'visits','s:19:\"a:1:{i:0;s:2:\"-1\";}\";'),(243,144,'sites','4'),(244,144,'address','כתובת 2'),(245,144,'department','אורתופדיה'),(246,144,'targets','-1'),(247,144,'contact',''),(248,144,'phone',''),(249,144,'pickup','-1'),(250,144,'zone','1'),(251,144,'courier','6'),(252,144,'courier_email','email1@email1.com'),(253,144,'taxi_hour','10'),(254,144,'taxi_mins','30'),(255,144,'hour_from','8'),(256,144,'hour_to','10'),(257,144,'date',''),(258,144,'notes',''),(259,144,'_wp_trash_meta_status','publish'),(260,144,'_wp_trash_meta_time','1512306680'),(261,144,'_wp_desired_post_slug','form-sent-by-oshikernst-on-131104-111-pm'),(298,146,'ctcodes','-1'),(299,146,'visits','s:19:\"a:1:{i:0;s:2:\"-1\";}\";'),(300,146,'sites','4'),(301,146,'address','כתובת 2'),(302,146,'department','אורתופדיה'),(303,146,'targets','-1'),(304,146,'contact',''),(305,146,'phone',''),(306,146,'pickup','-1'),(307,146,'zone','1'),(308,146,'courier','6'),(309,146,'courier_email','email1@email1.com'),(310,146,'taxi_hour','10'),(311,146,'taxi_mins','30'),(312,146,'hour_from','8'),(313,146,'hour_to','10'),(314,146,'date',''),(315,146,'notes',''),(316,146,'_wp_trash_meta_status','publish'),(317,146,'_wp_trash_meta_time','1512310161'),(318,146,'_wp_desired_post_slug','form-sent-by-oshikernst-on-140901-209-pm'),(321,148,'ctcodes','1'),(322,148,'visits','s:19:\"a:1:{i:0;s:2:\"-1\";}\";'),(323,148,'sites','4'),(324,148,'address','כתובת 2'),(325,148,'department','אורתופדיה'),(326,148,'targets','-1'),(327,148,'contact',''),(328,148,'phone',''),(329,148,'pickup','-1'),(330,148,'zone','1'),(331,148,'courier','6'),(332,148,'courier_email','email1@email1.com'),(333,148,'taxi_hour','10'),(334,148,'taxi_mins','30'),(335,148,'hour_from','8'),(336,148,'hour_to','10'),(337,148,'date',''),(338,148,'notes',''),(341,149,'ctcodes','1'),(342,149,'visits','s:19:\"a:1:{i:0;s:2:\"-1\";}\";'),(343,149,'sites','4'),(344,149,'address','כתובת 2'),(345,149,'department','אורתופדיה'),(346,149,'targets','-1'),(347,149,'contact',''),(348,149,'phone',''),(349,149,'pickup','-1'),(350,149,'zone','1'),(351,149,'courier','6'),(352,149,'courier_email','email1@email1.com'),(353,149,'taxi_hour','10'),(354,149,'taxi_mins','30'),(355,149,'hour_from','8'),(356,149,'hour_to','10'),(357,149,'date',''),(358,149,'notes',''),(359,149,'_wp_trash_meta_status','publish'),(360,149,'_wp_trash_meta_time','1512313946'),(361,149,'_wp_desired_post_slug','form-sent-by-oshikernst-on-151129-311-pm'),(362,148,'_wp_trash_meta_status','publish'),(363,148,'_wp_trash_meta_time','1512313950'),(364,148,'_wp_desired_post_slug','form-sent-by-oshikernst-on-151000-310-pm');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (1,1,'2017-11-18 18:50:15','2017-11-18 18:50:15','Welcome to WordPress. This is your first post. Edit or delete it, then start writing!','Hello world!','','trash','open','open','','hello-world__trashed','','','2017-12-01 21:24:18','2017-12-01 21:24:18','',0,'http://localhost/aml/?p=1',0,'post','',1),(22,1,'2017-11-18 19:38:11','2017-11-18 19:38:11','','User','','publish','closed','closed','','user','','','2017-11-18 20:20:23','2017-11-18 20:20:23','',0,'http://localhost/aml/?page_id=22',1,'page','',0),(23,1,'2017-11-18 19:38:11','2017-11-18 19:38:11','','Users','','inherit','closed','closed','','22-revision-v1','','','2017-11-18 19:38:11','2017-11-18 19:38:11','',22,'http://localhost/aml/2017/11/18/22-revision-v1/',0,'revision','',0),(24,1,'2017-11-18 20:20:23','2017-11-18 20:20:23','','User','','inherit','closed','closed','','22-revision-v1','','','2017-11-18 20:20:23','2017-11-18 20:20:23','',22,'http://localhost/aml/2017/11/18/22-revision-v1/',0,'revision','',0),(29,1,'2017-11-19 07:09:35','2017-11-19 07:09:35','','Login','','publish','closed','closed','','login_page','','','2017-11-19 10:07:12','2017-11-19 10:07:12','',0,'http://localhost/aml/?page_id=29',2,'page','',0),(30,1,'2017-11-19 07:09:35','2017-11-19 07:09:35','','Login','','inherit','closed','closed','','29-revision-v1','','','2017-11-19 07:09:35','2017-11-19 07:09:35','',29,'http://localhost/aml/2017/11/19/29-revision-v1/',0,'revision','',0),(31,1,'2017-11-19 07:13:14','2017-11-19 07:13:14','','Login_page','','inherit','closed','closed','','29-revision-v1','','','2017-11-19 07:13:14','2017-11-19 07:13:14','',29,'http://localhost/aml/2017/11/19/29-revision-v1/',0,'revision','',0),(32,1,'2017-11-19 07:24:55','2017-11-19 07:24:55','','Users','','publish','closed','closed','','users','','','2017-11-19 08:07:02','2017-11-19 08:07:02','',0,'http://localhost/aml/?page_id=32',3,'page','',0),(33,1,'2017-11-19 07:24:55','2017-11-19 07:24:55','','users','','inherit','closed','closed','','32-revision-v1','','','2017-11-19 07:24:55','2017-11-19 07:24:55','',32,'http://localhost/aml/2017/11/19/32-revision-v1/',0,'revision','',0),(34,1,'2017-11-19 08:07:02','2017-11-19 08:07:02','','Users','','inherit','closed','closed','','32-revision-v1','','','2017-11-19 08:07:02','2017-11-19 08:07:02','',32,'http://localhost/aml/2017/11/19/32-revision-v1/',0,'revision','',0),(35,1,'2017-11-19 08:16:37','2017-11-19 08:16:37','','Add User','','publish','closed','closed','','add-user','','','2017-11-19 08:16:37','2017-11-19 08:16:37','',0,'http://localhost/aml/?page_id=35',4,'page','',0),(36,1,'2017-11-19 08:16:37','2017-11-19 08:16:37','','Add User','','inherit','closed','closed','','35-revision-v1','','','2017-11-19 08:16:37','2017-11-19 08:16:37','',35,'http://localhost/aml/2017/11/19/35-revision-v1/',0,'revision','',0),(37,1,'2017-11-19 09:34:30','2017-11-19 09:34:30','','Clinical Trials','','publish','closed','closed','','clinical-trials','','','2017-11-19 09:34:30','2017-11-19 09:34:30','',0,'http://localhost/aml/?page_id=37',5,'page','',0),(38,1,'2017-11-19 09:34:30','2017-11-19 09:34:30','','Clinical Trials','','inherit','closed','closed','','37-revision-v1','','','2017-11-19 09:34:30','2017-11-19 09:34:30','',37,'http://localhost/aml/2017/11/19/37-revision-v1/',0,'revision','',0),(52,1,'2017-11-19 10:07:12','2017-11-19 10:07:12','','Login','','inherit','closed','closed','','29-revision-v1','','','2017-11-19 10:07:12','2017-11-19 10:07:12','',29,'http://localhost/aml/2017/11/19/29-revision-v1/',0,'revision','',0),(59,1,'2017-11-19 10:21:14','2017-11-19 10:21:14','','Clinical Trial','','publish','closed','closed','','clinical-trial','','','2017-11-19 10:29:15','2017-11-19 10:29:15','',0,'http://localhost/aml/?page_id=59',6,'page','',0),(60,1,'2017-11-19 10:21:14','2017-11-19 10:21:14','','Clinical Trial','','inherit','closed','closed','','59-revision-v1','','','2017-11-19 10:21:14','2017-11-19 10:21:14','',59,'http://localhost/aml/59-revision-v1/',0,'revision','',0),(61,1,'2017-11-19 14:11:44','2017-11-19 14:11:44','','Add Clinical Trial','','publish','closed','closed','','add-clinical-trial','','','2017-11-19 14:11:44','2017-11-19 14:11:44','',0,'http://localhost/aml/?page_id=61',7,'page','',0),(62,1,'2017-11-19 14:11:44','2017-11-19 14:11:44','','Add Clinical Trial','','inherit','closed','closed','','61-revision-v1','','','2017-11-19 14:11:44','2017-11-19 14:11:44','',61,'http://localhost/aml/61-revision-v1/',0,'revision','',0),(63,1,'2017-11-20 08:05:52','2017-11-20 08:05:52','','Sites','','publish','closed','closed','','sites','','','2017-11-20 08:05:52','2017-11-20 08:05:52','',0,'http://localhost/aml/?page_id=63',8,'page','',0),(64,1,'2017-11-20 08:05:52','2017-11-20 08:05:52','','Sites','','inherit','closed','closed','','63-revision-v1','','','2017-11-20 08:05:52','2017-11-20 08:05:52','',63,'http://localhost/aml/63-revision-v1/',0,'revision','',0),(77,1,'2017-11-20 09:15:21','2017-11-20 09:15:21','','Site','','publish','closed','closed','','site','','','2017-11-20 09:15:21','2017-11-20 09:15:21','',0,'http://localhost/aml/?page_id=77',0,'page','',0),(78,1,'2017-11-20 09:15:21','2017-11-20 09:15:21','','Site','','inherit','closed','closed','','77-revision-v1','','','2017-11-20 09:15:21','2017-11-20 09:15:21','',77,'http://localhost/aml/77-revision-v1/',0,'revision','',0),(79,1,'2017-11-20 09:27:09','2017-11-20 09:27:09','','Add Site','','publish','closed','closed','','add-site','','','2017-11-20 09:27:09','2017-11-20 09:27:09','',0,'http://localhost/aml/?page_id=79',0,'page','',0),(80,1,'2017-11-20 09:27:09','2017-11-20 09:27:09','','Add Site','','inherit','closed','closed','','79-revision-v1','','','2017-11-20 09:27:09','2017-11-20 09:27:09','',79,'http://localhost/aml/79-revision-v1/',0,'revision','',0),(81,1,'2017-11-20 10:44:54','2017-11-20 10:44:54','','Visits','','publish','closed','closed','','visits','','','2017-11-20 10:44:54','2017-11-20 10:44:54','',0,'http://localhost/aml/?page_id=81',0,'page','',0),(84,1,'2017-11-20 10:44:54','2017-11-20 10:44:54','','Visits','','inherit','closed','closed','','81-revision-v1','','','2017-11-20 10:44:54','2017-11-20 10:44:54','',81,'http://localhost/aml/81-revision-v1/',0,'revision','',0),(85,1,'2017-11-20 10:45:30','2017-11-20 10:45:30','','Visit','','publish','closed','closed','','visit','','','2017-11-20 10:45:30','2017-11-20 10:45:30','',0,'http://localhost/aml/?page_id=85',0,'page','',0),(86,1,'2017-11-20 10:45:30','2017-11-20 10:45:30','','Visit','','inherit','closed','closed','','85-revision-v1','','','2017-11-20 10:45:30','2017-11-20 10:45:30','',85,'http://localhost/aml/85-revision-v1/',0,'revision','',0),(87,1,'2017-11-20 10:45:39','2017-11-20 10:45:39','','Add Visit','','publish','closed','closed','','add-visit','','','2017-11-20 10:45:39','2017-11-20 10:45:39','',0,'http://localhost/aml/?page_id=87',0,'page','',0),(88,1,'2017-11-20 10:45:39','2017-11-20 10:45:39','','Add Visit','','inherit','closed','closed','','87-revision-v1','','','2017-11-20 10:45:39','2017-11-20 10:45:39','',87,'http://localhost/aml/87-revision-v1/',0,'revision','',0),(89,1,'2017-11-20 10:46:03','2017-11-20 10:46:03','','Pickup Types','','publish','closed','closed','','pickup-types','','','2017-11-20 10:46:21','2017-11-20 10:46:21','',0,'http://localhost/aml/?page_id=89',0,'page','',0),(90,1,'2017-11-20 10:46:03','2017-11-20 10:46:03','','Pickup Types','','inherit','closed','closed','','89-revision-v1','','','2017-11-20 10:46:03','2017-11-20 10:46:03','',89,'http://localhost/aml/89-revision-v1/',0,'revision','',0),(91,1,'2017-11-20 10:46:10','2017-11-20 10:46:10','','Pickup Type','','inherit','closed','closed','','89-revision-v1','','','2017-11-20 10:46:10','2017-11-20 10:46:10','',89,'http://localhost/aml/89-revision-v1/',0,'revision','',0),(92,1,'2017-11-20 10:46:21','2017-11-20 10:46:21','','Pickup Types','','inherit','closed','closed','','89-revision-v1','','','2017-11-20 10:46:21','2017-11-20 10:46:21','',89,'http://localhost/aml/89-revision-v1/',0,'revision','',0),(93,1,'2017-11-20 10:46:27','2017-11-20 10:46:27','','Pickup Type','','publish','closed','closed','','pickup-type','','','2017-11-20 10:46:27','2017-11-20 10:46:27','',0,'http://localhost/aml/?page_id=93',0,'page','',0),(94,1,'2017-11-20 10:46:27','2017-11-20 10:46:27','','Pickup Type','','inherit','closed','closed','','93-revision-v1','','','2017-11-20 10:46:27','2017-11-20 10:46:27','',93,'http://localhost/aml/93-revision-v1/',0,'revision','',0),(95,1,'2017-11-20 10:46:36','2017-11-20 10:46:36','','Add Pickup Type','','publish','closed','closed','','add-pickup-type','','','2017-11-20 10:46:36','2017-11-20 10:46:36','',0,'http://localhost/aml/?page_id=95',0,'page','',0),(96,1,'2017-11-20 10:46:36','2017-11-20 10:46:36','','Add Pickup Type','','inherit','closed','closed','','95-revision-v1','','','2017-11-20 10:46:36','2017-11-20 10:46:36','',95,'http://localhost/aml/95-revision-v1/',0,'revision','',0),(97,1,'2017-11-20 10:46:49','2017-11-20 10:46:49','','Couriers','','publish','closed','closed','','couriers','','','2017-11-20 10:46:49','2017-11-20 10:46:49','',0,'http://localhost/aml/?page_id=97',0,'page','',0),(98,1,'2017-11-20 10:46:49','2017-11-20 10:46:49','','Couriers','','inherit','closed','closed','','97-revision-v1','','','2017-11-20 10:46:49','2017-11-20 10:46:49','',97,'http://localhost/aml/97-revision-v1/',0,'revision','',0),(99,1,'2017-11-20 10:47:00','2017-11-20 10:47:00','','Courier','','publish','closed','closed','','courier','','','2017-11-20 10:47:00','2017-11-20 10:47:00','',0,'http://localhost/aml/?page_id=99',0,'page','',0),(100,1,'2017-11-20 10:47:00','2017-11-20 10:47:00','','Courier','','inherit','closed','closed','','99-revision-v1','','','2017-11-20 10:47:00','2017-11-20 10:47:00','',99,'http://localhost/aml/99-revision-v1/',0,'revision','',0),(101,1,'2017-11-20 10:47:08','2017-11-20 10:47:08','','Add Courier','','publish','closed','closed','','add-courier','','','2017-11-20 10:47:08','2017-11-20 10:47:08','',0,'http://localhost/aml/?page_id=101',0,'page','',0),(102,1,'2017-11-20 10:47:08','2017-11-20 10:47:08','','Add Courier','','inherit','closed','closed','','101-revision-v1','','','2017-11-20 10:47:08','2017-11-20 10:47:08','',101,'http://localhost/aml/101-revision-v1/',0,'revision','',0),(103,1,'2017-11-22 10:38:22','2017-11-22 10:38:22','','New Form','','publish','closed','closed','','new-form','','','2017-11-22 10:38:22','2017-11-22 10:38:22','',0,'http://localhost/aml/?page_id=103',0,'page','',0),(105,1,'2017-11-22 10:38:22','2017-11-22 10:38:22','','New Form','','inherit','closed','closed','','103-revision-v1','','','2017-11-22 10:38:22','2017-11-22 10:38:22','',103,'http://localhost/aml/103-revision-v1/',0,'revision','',0),(107,1,'2017-11-26 07:58:17','2017-11-26 07:58:17','','Zones','','publish','closed','closed','','zones','','','2017-11-26 07:58:17','2017-11-26 07:58:17','',0,'http://localhost/aml/?page_id=107',0,'page','',0),(108,1,'2017-11-26 07:58:11','2017-11-26 07:58:11','','Zones','','inherit','closed','closed','','107-revision-v1','','','2017-11-26 07:58:11','2017-11-26 07:58:11','',107,'http://localhost/aml/107-revision-v1/',0,'revision','',0),(109,1,'2017-11-26 07:58:37','2017-11-26 07:58:37','','Add Zone','','publish','closed','closed','','add-zone','','','2017-11-26 07:58:37','2017-11-26 07:58:37','',0,'http://localhost/aml/?page_id=109',0,'page','',0),(110,1,'2017-11-26 07:58:37','2017-11-26 07:58:37','','Add Zone','','inherit','closed','closed','','109-revision-v1','','','2017-11-26 07:58:37','2017-11-26 07:58:37','',109,'http://localhost/aml/109-revision-v1/',0,'revision','',0),(111,1,'2017-11-26 07:58:54','2017-11-26 07:58:54','','Zone','','publish','closed','closed','','zone','','','2017-11-26 07:58:54','2017-11-26 07:58:54','',0,'http://localhost/aml/?page_id=111',0,'page','',0),(112,1,'2017-11-26 07:58:54','2017-11-26 07:58:54','','Zone','','inherit','closed','closed','','111-revision-v1','','','2017-11-26 07:58:54','2017-11-26 07:58:54','',111,'http://localhost/aml/111-revision-v1/',0,'revision','',0),(125,1,'2017-11-26 08:25:49','2017-11-26 08:25:49','','Targets','','publish','closed','closed','','targets','','','2017-11-26 08:25:49','2017-11-26 08:25:49','',0,'http://localhost/aml/?page_id=125',0,'page','',0),(126,1,'2017-11-26 08:25:49','2017-11-26 08:25:49','','Targets','','inherit','closed','closed','','125-revision-v1','','','2017-11-26 08:25:49','2017-11-26 08:25:49','',125,'http://localhost/aml/125-revision-v1/',0,'revision','',0),(127,1,'2017-11-26 08:26:02','2017-11-26 08:26:02','','Target','','publish','closed','closed','','target','','','2017-11-26 08:26:02','2017-11-26 08:26:02','',0,'http://localhost/aml/?page_id=127',0,'page','',0),(128,1,'2017-11-26 08:26:02','2017-11-26 08:26:02','','Target','','inherit','closed','closed','','127-revision-v1','','','2017-11-26 08:26:02','2017-11-26 08:26:02','',127,'http://localhost/aml/127-revision-v1/',0,'revision','',0),(129,1,'2017-11-26 08:26:13','2017-11-26 08:26:13','','Add Target','','publish','closed','closed','','add-target','','','2017-11-26 08:26:13','2017-11-26 08:26:13','',0,'http://localhost/aml/?page_id=129',0,'page','',0),(130,1,'2017-11-26 08:26:13','2017-11-26 08:26:13','','Add Target','','inherit','closed','closed','','129-revision-v1','','','2017-11-26 08:26:13','2017-11-26 08:26:13','',129,'http://localhost/aml/129-revision-v1/',0,'revision','',0),(131,1,'2017-11-30 21:57:26','2017-11-30 21:57:26','Form Sent by Oshik Ernst on 21:57:26, 9:57 pm','Form Sent by Oshik Ernst on 21:57:26, 9:57 pm','','trash','open','open','','form-sent-by-oshik-ernst-on-215726-957-pm__trashed','','','2017-12-01 21:34:29','2017-12-01 21:34:29','',0,'http://localhost/aml/form-sent-by-oshik-ernst-on-215726-957-pm/',0,'post','',0),(132,1,'2017-11-30 21:58:12','2017-11-30 21:58:12','Form Sent by Oshik Ernst on 21:58:12, 9:58 pm','Form Sent by Oshik Ernst on 21:58:12, 9:58 pm','','publish','open','open','','form-sent-by-oshik-ernst-on-215812-958-pm','','','2017-11-30 21:58:12','2017-11-30 21:58:12','',0,'http://localhost/aml/form-sent-by-oshik-ernst-on-215812-958-pm/',0,'post','',0),(133,1,'2017-11-30 21:58:52','2017-11-30 21:58:52','Form Sent by Oshik Ernst on 21:58:52, 9:58 pm','Form Sent by Oshik Ernst on 21:58:52, 9:58 pm','','publish','open','open','','form-sent-by-oshik-ernst-on-215852-958-pm','','','2017-11-30 21:58:52','2017-11-30 21:58:52','',0,'http://localhost/aml/form-sent-by-oshik-ernst-on-215852-958-pm/',0,'post','',0),(134,1,'2017-11-30 22:01:25','2017-11-30 22:01:25','Form Sent by Oshik Ernst on 22:01:25, 10:01 pm','Form Sent by Oshik Ernst on 22:01:25, 10:01 pm','','publish','open','open','','form-sent-by-oshik-ernst-on-220125-1001-pm','','','2017-12-06 09:11:51','2017-12-06 09:11:51','',0,'http://localhost/aml/form-sent-by-oshik-ernst-on-220125-1001-pm/',0,'post','',0),(135,1,'2017-12-01 21:22:07','2017-12-01 21:22:07','','Forms','','publish','closed','closed','','forms','','','2017-12-01 21:22:07','2017-12-01 21:22:07','',0,'http://localhost/aml/?page_id=135',0,'page','',0),(136,1,'2017-12-01 21:22:07','2017-12-01 21:22:07','','Forms','','inherit','closed','closed','','135-revision-v1','','','2017-12-01 21:22:07','2017-12-01 21:22:07','',135,'http://localhost/aml/135-revision-v1/',0,'revision','',0),(137,1,'2017-12-01 21:24:18','2017-12-01 21:24:18','Welcome to WordPress. This is your first post. Edit or delete it, then start writing!','Hello world!','','inherit','closed','closed','','1-revision-v1','','','2017-12-01 21:24:18','2017-12-01 21:24:18','',1,'http://localhost/aml/1-revision-v1/',0,'revision','',0),(138,1,'2017-12-01 21:34:29','2017-12-01 21:34:29','Form Sent by Oshik Ernst on 21:57:26, 9:57 pm','Form Sent by Oshik Ernst on 21:57:26, 9:57 pm','','inherit','closed','closed','','131-revision-v1','','','2017-12-01 21:34:29','2017-12-01 21:34:29','',131,'http://localhost/aml/131-revision-v1/',0,'revision','',0),(139,1,'2017-12-01 21:49:55','2017-12-01 21:49:55','','Form','','publish','closed','closed','','form','','','2017-12-01 21:49:55','2017-12-01 21:49:55','',0,'http://localhost/aml/?page_id=139',0,'page','',0),(140,1,'2017-12-01 21:49:55','2017-12-01 21:49:55','','Form','','inherit','closed','closed','','139-revision-v1','','','2017-12-01 21:49:55','2017-12-01 21:49:55','',139,'http://localhost/aml/139-revision-v1/',0,'revision','',0),(141,1,'2017-12-03 12:59:47','2017-12-03 12:59:47','Form Sent by Oshik Ernst on 22:01:25, 10:01 pm','Form Sent by Oshik Ernst on 22:01:25, 10:01 pm','','inherit','closed','closed','','134-revision-v1','','','2017-12-03 12:59:47','2017-12-03 12:59:47','',134,'http://localhost/aml/134-revision-v1/',0,'revision','',0),(142,1,'2017-12-03 13:05:17','2017-12-03 13:05:17','Form Sent by oshikernst                        <input type= on 13:05:17, 1:05 pm','Form Sent by oshikernst                        <input type= on 13:05:17, 1:05 pm','','trash','open','open','','form-sent-by-oshikernst__trashed','','','2017-12-03 13:05:59','2017-12-03 13:05:59','',0,'http://localhost/aml/form-sent-by-oshikernst/',0,'post','',0),(143,1,'2017-12-03 13:05:59','2017-12-03 13:05:59','Form Sent by oshikernst                        <input type= on 13:05:17, 1:05 pm','Form Sent by oshikernst                        <input type= on 13:05:17, 1:05 pm','','inherit','closed','closed','','142-revision-v1','','','2017-12-03 13:05:59','2017-12-03 13:05:59','',142,'http://localhost/aml/142-revision-v1/',0,'revision','',0),(144,1,'2017-12-03 13:11:04','2017-12-03 13:11:04','Form Sent by oshikernst on 13:11:04, 1:11 pm','Form Sent by oshikernst on 13:11:04, 1:11 pm','','trash','open','open','','form-sent-by-oshikernst-on-131104-111-pm__trashed','','','2017-12-03 13:11:20','2017-12-03 13:11:20','',0,'http://localhost/aml/form-sent-by-oshikernst-on-131104-111-pm/',0,'post','',0),(145,1,'2017-12-03 13:11:20','2017-12-03 13:11:20','Form Sent by oshikernst on 13:11:04, 1:11 pm','Form Sent by oshikernst on 13:11:04, 1:11 pm','','inherit','closed','closed','','144-revision-v1','','','2017-12-03 13:11:20','2017-12-03 13:11:20','',144,'http://localhost/aml/144-revision-v1/',0,'revision','',0),(146,1,'2017-12-03 14:09:01','2017-12-03 14:09:01','Form Sent by oshikernst on 14:09:01, 2:09 pm','Form Sent by oshikernst on 14:09:01, 2:09 pm','','trash','open','open','','form-sent-by-oshikernst-on-140901-209-pm__trashed','','','2017-12-03 14:09:21','2017-12-03 14:09:21','',0,'http://localhost/aml/form-sent-by-oshikernst-on-140901-209-pm/',0,'post','',0),(147,1,'2017-12-03 14:09:21','2017-12-03 14:09:21','Form Sent by oshikernst on 14:09:01, 2:09 pm','Form Sent by oshikernst on 14:09:01, 2:09 pm','','inherit','closed','closed','','146-revision-v1','','','2017-12-03 14:09:21','2017-12-03 14:09:21','',146,'http://localhost/aml/146-revision-v1/',0,'revision','',0),(148,1,'2017-12-03 15:10:00','2017-12-03 15:10:00','Form Sent by oshikernst on 15:10:00, 3:10 pm','Form Sent by oshikernst on 15:10:00, 3:10 pm','','trash','open','open','','form-sent-by-oshikernst-on-151000-310-pm__trashed','','','2017-12-03 15:12:30','2017-12-03 15:12:30','',0,'http://localhost/aml/form-sent-by-oshikernst-on-151000-310-pm/',0,'post','',0),(149,1,'2017-12-03 15:11:29','2017-12-03 15:11:29','Form Sent by oshikernst on 15:11:29, 3:11 pm','Form Sent by oshikernst on 15:11:29, 3:11 pm','','trash','open','open','','form-sent-by-oshikernst-on-151129-311-pm__trashed','','','2017-12-03 15:12:26','2017-12-03 15:12:26','',0,'http://localhost/aml/form-sent-by-oshikernst-on-151129-311-pm/',0,'post','',0),(150,1,'2017-12-03 15:12:26','2017-12-03 15:12:26','Form Sent by oshikernst on 15:11:29, 3:11 pm','Form Sent by oshikernst on 15:11:29, 3:11 pm','','inherit','closed','closed','','149-revision-v1','','','2017-12-03 15:12:26','2017-12-03 15:12:26','',149,'http://localhost/aml/149-revision-v1/',0,'revision','',0),(151,1,'2017-12-03 15:12:30','2017-12-03 15:12:30','Form Sent by oshikernst on 15:10:00, 3:10 pm','Form Sent by oshikernst on 15:10:00, 3:10 pm','','inherit','closed','closed','','148-revision-v1','','','2017-12-03 15:12:30','2017-12-03 15:12:30','',148,'http://localhost/aml/148-revision-v1/',0,'revision','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (1,1,0),(131,1,0),(132,1,0),(133,1,0),(134,1,0),(142,1,0),(144,1,0),(146,1,0),(148,1,0),(149,1,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,3),(2,2,'category','',0,0);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'ראשי','%d7%a8%d7%90%d7%a9%d7%99',0),(2,'בינלאומי','%d7%91%d7%99%d7%a0%d7%9c%d7%90%d7%95%d7%9e%d7%99',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','OshikErnst'),(2,1,'first_name','Oshik'),(3,1,'last_name','Ernst'),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'syntax_highlighting','true'),(7,1,'comment_shortcuts','false'),(8,1,'admin_color','fresh'),(9,1,'use_ssl','0'),(10,1,'show_admin_bar_front','true'),(11,1,'locale',''),(12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(13,1,'wp_user_level','10'),(14,1,'dismissed_wp_pointers','theme_editor_notice,apm_install'),(15,1,'show_welcome_panel','0'),(17,1,'wp_dashboard_quick_press_last_post_id','106'),(18,1,'community-events-location','a:1:{s:2:\"ip\";s:2:\"::\";}'),(19,1,'display_name','ernst'),(20,1,'address',''),(21,1,'city',''),(22,1,'province',''),(23,1,'postalcode',''),(24,2,'nickname','ANANAS'),(25,2,'first_name','ana'),(26,2,'last_name','nas'),(27,2,'description',''),(28,2,'rich_editing','true'),(29,2,'syntax_highlighting','true'),(30,2,'comment_shortcuts','false'),(31,2,'admin_color','fresh'),(32,2,'use_ssl','0'),(33,2,'show_admin_bar_front','true'),(34,2,'locale',''),(35,2,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(36,2,'wp_user_level','0'),(37,2,'dismissed_wp_pointers',''),(38,2,'display_name','ANANAS'),(39,2,'address',''),(40,2,'city',''),(41,2,'province',''),(42,2,'postalcode',''),(43,1,'phonenumber','0502066635'),(44,1,'ctcodes','a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}'),(45,1,'sites','4'),(46,2,'phonenumber','502066635'),(47,2,'ctcodes','a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}'),(48,2,'sites','1'),(118,8,'nickname','testuser'),(119,8,'first_name','test'),(120,8,'last_name','userrrr'),(121,8,'description',''),(122,8,'rich_editing','true'),(123,8,'syntax_highlighting','true'),(124,8,'comment_shortcuts','false'),(125,8,'admin_color','fresh'),(126,8,'use_ssl','0'),(127,8,'show_admin_bar_front','true'),(128,8,'locale',''),(129,8,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(130,8,'wp_user_level','10'),(131,8,'phonenumber','050000000'),(132,8,'ctcodes','a:1:{i:0;s:1:\"2\";}'),(133,8,'sites','a:1:{i:0;s:1:\"3\";}'),(152,10,'nickname','Natalie'),(153,10,'first_name','natali'),(154,10,'last_name','e'),(155,10,'description',''),(156,10,'rich_editing','true'),(157,10,'syntax_highlighting','true'),(158,10,'comment_shortcuts','false'),(159,10,'admin_color','fresh'),(160,10,'use_ssl','0'),(161,10,'show_admin_bar_front','true'),(162,10,'locale',''),(163,10,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(164,10,'wp_user_level','0'),(165,10,'phonenumber','0502000000'),(166,10,'ctcodes','a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"4\";}'),(167,10,'sites','1'),(168,1,'session_tokens','a:2:{s:64:\"8f7f71b8eb1f651c70221bc9e84dc80b5f749ce9f20d0c9be96bb821b3303e1f\";a:4:{s:10:\"expiration\";i:1513069334;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36\";s:5:\"login\";i:1511859734;}s:64:\"da3c0deb5d8e827f7b79b5a79c1956e672f0951e01d609cabf97bcab8be5fb2a\";a:4:{s:10:\"expiration\";i:1513604013;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36\";s:5:\"login\";i:1512394413;}}'),(170,1,'closedpostboxes_post','a:0:{}'),(171,1,'metaboxhidden_post','a:6:{i:0;s:11:\"postexcerpt\";i:1;s:13:\"trackbacksdiv\";i:2;s:16:\"commentstatusdiv\";i:3;s:11:\"commentsdiv\";i:4;s:7:\"slugdiv\";i:5;s:9:\"authordiv\";}'),(172,11,'nickname','roberta'),(173,11,'first_name','roberta'),(174,11,'last_name','flack'),(175,11,'description',''),(176,11,'rich_editing','true'),(177,11,'syntax_highlighting','true'),(178,11,'comment_shortcuts','false'),(179,11,'admin_color','fresh'),(180,11,'use_ssl','0'),(181,11,'show_admin_bar_front','true'),(182,11,'locale',''),(183,11,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(184,11,'wp_user_level','0'),(185,11,'phonenumber','0500000000'),(186,11,'ctcodes','a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}'),(187,11,'sites','1'),(188,12,'nickname','avner123'),(189,12,'first_name','avner'),(190,12,'last_name','chen'),(191,12,'description',''),(192,12,'rich_editing','true'),(193,12,'syntax_highlighting','true'),(194,12,'comment_shortcuts','false'),(195,12,'admin_color','fresh'),(196,12,'use_ssl','0'),(197,12,'show_admin_bar_front','true'),(198,12,'locale',''),(199,12,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(200,12,'wp_user_level','0'),(201,12,'phonenumber','0500500500'),(202,12,'ctcodes','a:1:{i:0;s:1:\"2\";}'),(203,12,'sites','5');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'OshikErnst','$P$BCaR1OeE/sEEpQeUEVltZKaNw/PBM60','oshikernst','oshike@gmail.com','','2017-11-18 18:50:14','',0,'ernst'),(2,'ANANAS','$P$BX.AoI5PJyOSjSiQbm.pqnbVR6NRe60','ananas','ananas@gmail.com','','2017-11-18 20:49:11','1511038152:$P$B/jY8.MHmj8IhsoWOBDREGxYm4TCec0',0,'ANANAS'),(8,'testuser','$P$Bs10dJxf..3fFw8P.hWPO6ZpeNVKcI/','testuserrrr','test@test.com','','2017-11-20 14:42:19','',0,'test userrrr'),(10,'Natalie','$P$Bj8Ec7ILPvwa3nt/gXUwA9Ho73cj6w0','natalie','natalie@gmail.com','','2017-11-26 07:21:47','',0,'natali e'),(11,'roberta','$P$BSFfQ1bGZ0lpAZDPh2WBZQhbGb52jd1','robertaflack','roberto@gmail.com','','2017-12-04 19:11:55','',0,'roberta flack'),(12,'avner123','$P$BBdOjASwDY8GwcN37Yr0N1wF2nsyN71','avnerchen','avnerchen@gmail.com','','2017-12-04 19:15:34','',0,'avner chen');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 12:15:01


/* Duplicator WordPress Timestamp: 2017-12-06 10:15:01*/
/* DUPLICATOR_MYSQLDUMP_EOF */
