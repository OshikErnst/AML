<div class="wp_ultimate_csv_importer_pro panel" style="margin-left: 5%;margin-right:7%;margin-top: 50px">
<h3 style="text-align: center;color: #ec3429;padding-bottom: 10px !important;"> MORE  FREE  ADDONS </h3>
</div>
<div class="card" style="float: left;width: 20%;margin-left:  5%;margin-right: 5%">
    <h2 class="title6" style="font-size:medium;">Import Woocommerce</h2>
     <hr class="divider3"/>
    <b style="font-size: small;font-style: italic;">+ Few minutes import</b>
    <p style="padding-left: 11%;">Import all Woocommerce products</p>
    <b style="font-size: small;font-style: italic;">+ Custom Fields</b>
    <div style="padding-left: 11%;"><p>Woocommerce Product Add-ons, Chained Products, Product Retailers, Returns and Warranty Request, Pre Order</div>
    <b style="font-size: small;font-style: italic;">+ Supports</b> 
    <div style="padding-left: 11%;"><p>Easy import using CSV</p></div>
    <b style="font-size: small;font-style: italic;">+ Drag & Drop</b> 
    <div style="padding-left: 11%;"><p>Ease Drag & drop import</p></div>
   
    <a class="cus-button-3" href="https://wordpress.org/plugins/import-woocommerce/" target="blank">Install Now</a>
  
</div>
<div class="card" style="float: left;width: 20%;margin-left:  5%;margin-right: 5%">
    <h2 class="title4" style="font-size:medium;">Import Users</h2>
     <hr class="divider1"/>
    <b style="font-size: small;font-style: italic;">+ Few minutes import</b>
    <p style="padding-left: 11%;">Import all Users details</p>
    <b style="font-size: small;font-style: italic;">+ Custom Fields</b>
    <div style="padding-left: 11%;"><p>WP Members, Billing and Shipping Information</p></div>
    <b style="font-size: small;font-style: italic;">+ Supports</b> 
    <div style="padding-left: 11%;"><p>Easy import using CSV</p></div>
    
   <b style="font-size: small;font-style: italic;">+ Random password</b> 
    <div style="padding-left: 11%;"><p>If user password column is empty we will create random password and send it through email</p></div>
    <a class="cus-button-1" href="https://wordpress.org/plugins/import-users/" target="blank">Install Now</a>
  
</div>
<div class="card" style="float: left;width: 20%;margin-left:  5%;">
    <h2 class="title5" style="font-size:medium;">WP Ultimate Exporter</h2>
     <hr class="divider2"/>
    <b style="font-size: small;font-style: italic;">+ Few minutes Export</b>
    <p style="padding-left: 11%;">Export all your data from wordpress </p>
    <b style="font-size: small;font-style: italic;">+ Export Fields</b>
    <div style="padding-left: 11%;"><p>Posts, Pages, Users, All Custom Fields, Woocommerce, Marketpress, Wpecommerce, Comments, Reviews</p></div>
    <b style="font-size: small;font-style: italic;">+ Export Formats</b> 
    <div style="padding-left: 11%;"><p>Easy export as CSV</p></div>
    <b style="font-size: small;font-style: italic;">+ Filters</b> 
    <div style="padding-left: 11%;"><p>Ease filters to export</p></div>
   
    <a class="cus-button-2" href="https://wordpress.org/plugins/wp-ultimate-exporter/" target="blank">Install Now</a>
  
</div>